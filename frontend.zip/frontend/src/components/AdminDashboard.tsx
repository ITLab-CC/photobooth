import { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Button,
  List,
  ListItem,
  ListItemText,
} from '@mui/material';
import {
  listGalleries,
  deleteGallery,
  updateGalleryPin,
  GalleryResponse,
} from '../api';

interface AdminDashboardProps {
  token: string | null;
}

export default function AdminDashboard({ token }: AdminDashboardProps) {
  const [galleries, setGalleries] = useState<GalleryResponse[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token) return;
    listGalleries(token)
      .then((res) => {
        setGalleries(res.galleries);
      })
      .catch((err) => {
        console.error(err);
        setError('Fehler beim Laden der Galerien');
      });
  }, [token]);

  const handleDeleteGallery = async (galleryId: string) => {
    if (!token) return;
    try {
      await deleteGallery(token, galleryId);
      setGalleries((prev) => prev.filter((g) => g.gallery_id !== galleryId));
    } catch (err) {
      console.error(err);
      setError('Fehler beim Löschen der Galerie');
    }
  };

  const handleChangePin = async (galleryId: string) => {
    if (!token) return;
    const newPin = prompt('Neue PIN eingeben:');
    if (!newPin) return;
    try {
      await updateGalleryPin(token, galleryId, newPin);
      alert('PIN wurde geändert.');
    } catch (err) {
      console.error(err);
      setError('Fehler beim Ändern der PIN');
    }
  };

  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" gutterBottom>
        Admin Dashboard
      </Typography>
      {error && <Typography color="error">{error}</Typography>}
      <List>
        {galleries.map((gallery) => (
          <ListItem
            key={gallery.gallery_id}
            sx={{ display: 'flex', justifyContent: 'space-between' }}
          >
            <ListItemText
              primary={`Galerie: ${gallery.gallery_id}`}
              secondary={`Bilder: ${gallery.images.length} | Pin gesetzt: ${
                gallery.pin_set ? 'Ja' : 'Nein'
              }`}
            />
            <Box>
              <Button
                variant="contained"
                color="secondary"
                onClick={() => handleDeleteGallery(gallery.gallery_id)}
                sx={{ mr: 1 }}
              >
                Galerie löschen
              </Button>
              <Button
                variant="outlined"
                onClick={() => handleChangePin(gallery.gallery_id)}
              >
                PIN ändern
              </Button>
            </Box>
          </ListItem>
        ))}
      </List>
    </Box>
  );
}
