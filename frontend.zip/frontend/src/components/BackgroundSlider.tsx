// src/components/BackgroundSlider.tsx
import React, { useEffect, useState } from "react";
import { Box, IconButton, Paper } from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { listBackgrounds } from "../api";

interface BackgroundResponse {
  background_id: string;
}

interface BackgroundListResponse {
  backgrounds: BackgroundResponse[];
}

interface BackgroundSliderProps {
  token: string;
  onSelect?: (backgroundId: string) => void;
}

const BASE_URL = "https://photo.it-lab.cc"; // passe ggf. an

const BackgroundSlider: React.FC<BackgroundSliderProps> = ({ token, onSelect }) => {
  const [backgrounds, setBackgrounds] = useState<BackgroundResponse[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);

  useEffect(() => {
    listBackgrounds(token)
      .then((data: BackgroundListResponse) => {
        if (data.backgrounds && data.backgrounds.length > 0) {
          setBackgrounds(data.backgrounds);
          setSelectedIndex(0); // Beim Start: erstes Element als ausgewählt
        }
      })
      .catch((err) => {
        console.error("Fehler beim Laden der Hintergründe:", err);
      });
  }, [token]);

  // Immer das mittlere Element als ausgewählt zurückmelden:
  useEffect(() => {
    if (onSelect && backgrounds.length > 0) {
      onSelect(backgrounds[selectedIndex].background_id);
    }
  }, [selectedIndex, backgrounds, onSelect]);

  // Bestimme die anzuzeigenden Elemente:
  // Wenn es kein Vorgänger gibt, wird links ein Platzhalter (leeres Box) angezeigt.
  // Gleiches gilt für rechts, falls kein Nachfolger existiert.
  const leftItem = selectedIndex > 0 ? backgrounds[selectedIndex - 1] : null;
  const centerItem = backgrounds[selectedIndex];
  const rightItem =
    selectedIndex < backgrounds.length - 1 ? backgrounds[selectedIndex + 1] : null;

  const handlePrev = () => {
    if (selectedIndex > 0) {
      setSelectedIndex(selectedIndex - 1);
    }
  };

  const handleNext = () => {
    if (selectedIndex < backgrounds.length - 1) {
      setSelectedIndex(selectedIndex + 1);
    }
  };

  return (
    <Box display="flex" alignItems="center" mt={2}>
      <IconButton onClick={handlePrev} disabled={selectedIndex === 0}>
        <ArrowBackIosIcon />
      </IconButton>
      <Box display="flex" gap={1}>
        <Paper
          sx={{
            width: 150,
            height: 150,
            overflow: "hidden",
          }}
        >
          {leftItem ? (
            <Box
              component="img"
              src={`${BASE_URL}/api/v1/background/${leftItem.background_id}`}
              alt="Hintergrund"
              sx={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          ) : (
            <Box sx={{ width: "100%", height: "100%" }} />
          )}
        </Paper>
        <Paper
          sx={{
            width: 180,
            height: 180,
            overflow: "hidden",
            border: "4px solid #1976d2",
            transition: "transform 0.3s",
            transform: "scale(1.2)",
          }}
        >
          {centerItem && (
            <Box
              component="img"
              src={`${BASE_URL}/api/v1/background/${centerItem.background_id}`}
              alt="Hintergrund"
              sx={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          )}
        </Paper>
        <Paper
          sx={{
            width: 150,
            height: 150,
            overflow: "hidden",
          }}
        >
          {rightItem ? (
            <Box
              component="img"
              src={`${BASE_URL}/api/v1/background/${rightItem.background_id}`}
              alt="Hintergrund"
              sx={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          ) : (
            <Box sx={{ width: "100%", height: "100%" }} />
          )}
        </Paper>
      </Box>
      <IconButton onClick={handleNext} disabled={selectedIndex >= backgrounds.length - 1}>
        <ArrowForwardIosIcon />
      </IconButton>
    </Box>
  );
};

export default BackgroundSlider;
