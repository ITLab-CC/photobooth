// src/components/PinModal.tsx
import { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Button,
  TextField,
  Grid,
  IconButton,
} from "@mui/material";
import BackspaceIcon from "@mui/icons-material/Backspace";

interface PinModalProps {
  open: boolean;
  onSubmit: (pin: string) => void;
}

export default function PinModal({ open, onSubmit }: PinModalProps) {
  const [pin, setPin] = useState("");

  const handleButtonClick = (num: string) => {
    if (pin.length < 4) {
      setPin((prev) => prev + num);
    }
  };

  const handleBackspace = () => {
    setPin(pin.slice(0, -1));
  };

  const handleConfirm = () => {
    if (pin.length === 4) {
      onSubmit(pin);
    }
  };

  const isPinValid = () => /^\d{4}$/.test(pin);

  return (
    <Dialog open={open} disableEscapeKeyDown maxWidth="xs" fullWidth>
      <DialogTitle sx={{ textAlign: "center", fontWeight: "bold" }}>PIN Eingabe</DialogTitle>
      <DialogContent>
        <TextField
          value={pin}
          variant="outlined"
          fullWidth
          disabled
          placeholder="••••"
          inputProps={{
            style: { textAlign: "center", fontSize: "2rem", letterSpacing: "0.5rem" },
          }}
          sx={{ mb: 2 }}
        />
        <Grid container spacing={1}>
          {["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"].map((num) => (
            <Grid item xs={4} key={num}>
              <Button
                variant="outlined"
                onClick={() => handleButtonClick(num)}
                fullWidth
                sx={{ fontSize: "1.2rem", padding: "0.5rem" }}
              >
                {num}
              </Button>
            </Grid>
          ))}
          <Grid item xs={4}>
            <IconButton onClick={handleBackspace} sx={{ fontSize: "1.2rem", padding: "0.25rem" }}>
              <BackspaceIcon />
            </IconButton>
          </Grid>
          <Grid item xs={8}>
            <Button
              variant="contained"
              color="primary"
              onClick={handleConfirm}
              fullWidth
              disabled={!isPinValid()}
              sx={{ fontSize: "1rem", padding: "0.5rem" }}
            >
              Bestätigen
            </Button>
          </Grid>
        </Grid>
      </DialogContent>
    </Dialog>
  );
}
