declare module "canvas-confetti";
