import { useState, useEffect } from "react";
import { Box, Typography } from "@mui/material";
import { keyframes } from "@mui/system";
import AutoLogin from "../components/AutoLogin";
import DisclaimerModal from "../components/DisclaimerModal";
import PinModal from "../components/PinModal";
import CustomCameraComponent from "../components/CustomCameraComponent";
import BackgroundSlider from "../components/BackgroundSlider";
import { createGallery, GalleryResponse, setGalleryPin } from "../api";
import itlabImage from "../assets/itlab.png";

const backgroundAnimation = keyframes`
  0% { background: linear-gradient(45deg, #ff9a9e, #fad0c4); }
  33% { background: linear-gradient(45deg, #fad0c4, #a18cd1); }
  66% { background: linear-gradient(45deg, #a18cd1, #fbc2eb); }
  100% { background: linear-gradient(45deg, #fbc2eb, #ff9a9e); }
`;

export default function PhotoBoxPage() {
  const [token, setToken] = useState<string | null>(null);
  const [galleryId, setGalleryId] = useState<string | null>(null);
  const [showDisclaimer, setShowDisclaimer] = useState(true);
  const [showPinModal, setShowPinModal] = useState(false);
  const [userPin, setUserPin] = useState("");
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);

  useEffect(() => {
    if (token && !galleryId) {
      createGallery(token)
        .then((resp: GalleryResponse) => {
          console.log("Galerie erstellt:", resp.gallery_id);
          setGalleryId(resp.gallery_id);
        })
        .catch((err) => {
          console.error("Fehler beim Erstellen der Galerie:", err);
        });
    }
  }, [token, galleryId]);

  useEffect(() => {
    if (token && galleryId && userPin) {
      setGalleryPin(token, galleryId, userPin)
        .then((resp: GalleryResponse) => {
          console.log("PIN in Galerie gespeichert:", resp);
        })
        .catch((err) => {
          console.error("Fehler beim Setzen des PINs:", err);
        });
    }
  }, [token, galleryId, userPin]);

  const handleImageUpload = (imageId: string) => {
    setUploadedImages((prev) => [...prev, imageId]);
  };

  return (
    <Box
      sx={{
        animation: `${backgroundAnimation} 15s ease infinite`,
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: 2,
        position: "relative",
      }}
    >
      {!token && <AutoLogin onToken={setToken} />}

      {token && !galleryId && (
        <Typography variant="h5" color="white" sx={{ mb: 2 }}>
          Galerie wird erstellt…
        </Typography>
      )}

      {token && galleryId && showDisclaimer && (
        <DisclaimerModal
          open={showDisclaimer}
          onAccept={() => {
            setShowDisclaimer(false);
            setShowPinModal(true);
          }}
        />
      )}

      {token && galleryId && showPinModal && (
        <PinModal
          open={showPinModal}
          onSubmit={(pin) => {
            setUserPin(pin);
            setShowPinModal(false);
          }}
        />
      )}

      {token && galleryId && !showDisclaimer && !showPinModal && (
        <>
          <CustomCameraComponent
            galleryId={galleryId}
            pin={userPin}
            token={token}
            onImageUpload={handleImageUpload}
          />
          <Box mt={10}>
            <BackgroundSlider
              token={token}
              onSelect={(bgId) => console.log("Ausgewählter Hintergrund:", bgId)}
            />
          </Box>
        </>
      )}

      {uploadedImages.length > 0 && (
        <Box
          sx={{
            mt: 4,
            bgcolor: "rgba(255, 255, 255, 0.8)",
            p: 2,
            borderRadius: 1,
            maxWidth: 600,
          }}
        >
          <Typography variant="h6" align="center">
            Hochgeladene Bilder:
          </Typography>
          <ul>
            {uploadedImages.map((id) => (
              <li key={id}>
                <Typography variant="body2">Bild ID: {id}</Typography>
              </li>
            ))}
          </ul>
        </Box>
      )}

      <Box
        component="img"
        src={itlabImage}
        alt="Itlab Logo"
        sx={{
          position: "fixed",
          bottom: 16,
          right: 16,
          width: 100,
          opacity: 0.8,
        }}
      />
    </Box>
  );
}
