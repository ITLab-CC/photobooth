// src/pages/AdminPage.tsx
import { useEffect, useState } from 'react';
import { login, listGalleries, deleteGallery, updateGalleryPin, GalleryResponse } from '../api';

export default function AdminPage() {
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [galleries, setGalleries] = useState<GalleryResponse[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Falls adminToken existiert, lade Galerien
  useEffect(() => {
    if (!adminToken) return;
    listGalleries(adminToken)
      .then((res) => setGalleries(res.galleries))
      .catch(() => setError('Fehler beim Laden der Galerien'));
  }, [adminToken]);

  const handleLogin = async () => {
    try {
      const data = await login(username, password);
      setAdminToken(data.token);
    } catch (err) {
      setError('Admin-Login fehlgeschlagen');
    }
  };

  const handleDeleteGallery = async (galleryId: string) => {
    if (!adminToken) return;
    try {
      await deleteGallery(adminToken, galleryId);
      setGalleries((prev) => prev.filter((g) => g.gallery_id !== galleryId));
    } catch {
      setError('Fehler beim Löschen der Galerie');
    }
  };

  const handleChangePin = async (galleryId: string) => {
    if (!adminToken) return;
    const newPin = prompt('Neue PIN eingeben:');
    if (!newPin) return;
    try {
      await updateGalleryPin(adminToken, galleryId, newPin);
      alert('PIN geändert.');
    } catch {
      setError('Fehler beim Ändern der PIN');
    }
  };

  // Noch nicht eingeloggt -> Login-Form
  if (!adminToken) {
    return (
      <div style={{ padding: '1rem' }}>
        <h2>Admin Login</h2>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <div>
          <label>Username: </label>
          <input value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div>
          <label>Password: </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button onClick={handleLogin}>Login</button>
      </div>
    );
  }

  // Eingeloggt -> Dashboard
  return (
    <div style={{ padding: '1rem' }}>
      <h2>Admin Dashboard</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <ul>
        {galleries.map((g) => (
          <li key={g.gallery_id} style={{ marginBottom: '0.5rem' }}>
            <span>
              <strong>Galerie:</strong> {g.gallery_id} | Bilder: {g.images.length}{' '}
              | Pin gesetzt: {g.pin_set ? 'Ja' : 'Nein'}
            </span>
            <button onClick={() => handleDeleteGallery(g.gallery_id)}>Löschen</button>
            <button onClick={() => handleChangePin(g.gallery_id)}>PIN ändern</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
