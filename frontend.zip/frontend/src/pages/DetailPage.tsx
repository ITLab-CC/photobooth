// src/pages/DetailPage.tsx
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom'; 
import { getGalleryImagesByPin, GalleryImageListResponse } from '../api';

export default function DetailPage() {
  const [searchParams] = useSearchParams();
  const galleryId = searchParams.get('galleryId');
  const pin = searchParams.get('pin');
  const [images, setImages] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!galleryId || !pin) return;
    getGalleryImagesByPin(galleryId, pin)
      .then((res: GalleryImageListResponse) => {
        // res.images => array of { image_id, gallery }
        // wir bauen URLs
        const urls = res.images.map((imgObj) => 
          `/api/v1/gallery/${galleryId}/image/${imgObj.image_id}/pin/${pin}`
        );
        setImages(urls);
      })
      .catch(() => setError('Fehler beim Laden der Galerie-Bilder'));
  }, [galleryId, pin]);

  if (!galleryId || !pin) {
    return <p>Bitte galleryId und pin in der URL angeben.</p>;
  }

  return (
    <div style={{ padding: '1rem' }}>
      <h2>Detailansicht zu Galerie {galleryId}</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
        {images.map((url, idx) => (
          <img key={idx} src={url} alt={`Bild ${idx}`} style={{ width: '200px' }} />
        ))}
      </div>
    </div>
  );
}
