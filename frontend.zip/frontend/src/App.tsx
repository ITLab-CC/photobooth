// src/App.tsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import PhotoBoxPage from './pages/PhotoBoxPage';
import AdminPage from './pages/AdminPage';
import DetailPage from './pages/DetailPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Startseite (Fotobox) */}
        <Route path="/" element={<PhotoBoxPage />} />

        {/* Admin-Dashboard */}
        <Route path="/admin" element={<AdminPage />} />

        {/* Detail-Seite */}
        <Route path="/detail" element={<DetailPage />} />
      </Routes>
    </BrowserRouter>
  );
}
